package com.cts.pmsm.service;

import com.cts.pmsm.model.MedicalRepresentative;


public interface EmployeeService {
	
	public MedicalRepresentative addMedicalRepresentative(MedicalRepresentative medicalRepresentative);
	

}
