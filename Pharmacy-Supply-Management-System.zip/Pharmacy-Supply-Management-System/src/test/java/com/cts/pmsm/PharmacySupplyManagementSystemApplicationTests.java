package com.cts.pmsm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PharmacySupplyManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
