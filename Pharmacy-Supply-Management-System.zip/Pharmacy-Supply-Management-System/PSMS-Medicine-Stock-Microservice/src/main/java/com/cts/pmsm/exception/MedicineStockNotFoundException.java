package com.cts.pmsm.exception;

public class MedicineStockNotFoundException extends Exception{
	
	public MedicineStockNotFoundException(String message) {
		super(message);
	}

}
